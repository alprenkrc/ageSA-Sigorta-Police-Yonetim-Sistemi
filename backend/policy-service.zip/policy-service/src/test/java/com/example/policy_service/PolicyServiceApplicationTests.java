package com.example.policy_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolicyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
